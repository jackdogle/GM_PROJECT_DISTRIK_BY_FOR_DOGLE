/*==============================================================================


	Southclaw's Attachment Editor

		Easily edit and save attachment offsets using the SA:MP client-side
		on-screen controls.


==============================================================================*/


#include <a_samp>
#include <logger>
#include <YSI\y_utils>
#include <zcmd>


#define OUTPUT_FILE "SavedAttachments.txt"

enum {
	Float:COORD_X,
	Float:COORD_Y,
	Float:COORD_Z
}

enum {
	POS_OFFSET_X,
	POS_OFFSET_Y,
	POS_OFFSET_Z,
	ROT_OFFSET_X,
	ROT_OFFSET_Y,
	ROT_OFFSET_Z,
	SCALE_X,
	SCALE_Y,
	SCALE_Z
}


new AttachmentBones[18][16] = {
	{"Spine"},
	{"Head"},
	{"Left upper arm"},
	{"Right upper arm"},
	{"Left hand"},
	{"Right hand"},
	{"Left thigh"},
	{"Right thigh"},
	{"Left foot"},
	{"Right foot"},
	{"Right calf"},
	{"Left calf"},
	{"Left forearm"},
	{"Right forearm"},
	{"Left clavicle"},
	{"Right clavicle"},
	{"Neck"},
	{"Jaw"}
};

new
	bool:gEditingAttachments[MAX_PLAYERS],
	gCurrentAttachIndex[MAX_PLAYERS],
	bool:gIndexUsed[MAX_PLAYERS][MAX_PLAYER_ATTACHED_OBJECTS],
	gIndexModel[MAX_PLAYERS][MAX_PLAYER_ATTACHED_OBJECTS],
	gIndexBone[MAX_PLAYERS][MAX_PLAYER_ATTACHED_OBJECTS],
	Float:gIndexPos[MAX_PLAYERS][MAX_PLAYER_ATTACHED_OBJECTS][3],
	Float:gIndexRot[MAX_PLAYERS][MAX_PLAYER_ATTACHED_OBJECTS][3],
	Float:gIndexSca[MAX_PLAYERS][MAX_PLAYER_ATTACHED_OBJECTS][3],
	gCurrentAxisEdit[MAX_PLAYERS];
	

public OnScriptInit() {
	for(new i; i < MAX_PLAYERS; i++) {
		gCurrentAttachIndex[i] = 0;
		gIndexModel[i][0] = 18636;

		for(new j; j < MAX_PLAYER_ATTACHED_OBJECTS; j++) {
			gIndexUsed[i][j] = false;
			gIndexBone[i][j] = 1;
			gIndexSca[i][j][COORD_X] = 1.0;
			gIndexSca[i][j][COORD_Y] = 1.0;
			gIndexSca[i][j][COORD_Z] = 1.0;
		}
	}

	return 1;
}

public OnScriptExit() {
	for(new i; i < MAX_PLAYERS; i++) {
		if(gEditingAttachments[i]) {
			for(new j; j < MAX_PLAYER_ATTACHED_OBJECTS; j++) {
				if(gIndexUsed[i][j]) {
					RemovePlayerAttachedObject(i, j);
				}
			}
		}
	}

	return 1;
}

forward AttachEditFS(playerid);
public AttachEditFS(playerid)
{
	ShowMainEditMenu(playerid);
	return 1;
}

ShowMainEditMenu(playerid) {
	new string[552];

	format(string, sizeof(string),
		"Select Index (%d)\
		\nSelect Model (%d)\
		\nSelect Bone (%d)\
		\nX Position Offset (%.4f)\
		\nY Position Offset (%.4f)\
		\nZ Position Offset (%.4f)\
		\nX Rotation Offset (%.4f)\
		\nY Rotation Offset (%.4f)\
		\nZ Rotation Offset (%.4f)\
		\nX Scale (%.4f)\
		\nY Scale (%.4f)\
		\nZ Scale (%.4f)\
		\nEdit\
		\nClear Index\
		\nSave Attachment",
		gCurrentAttachIndex[playerid],
		gIndexModel[playerid][gCurrentAttachIndex[playerid]],
		gIndexBone[playerid][gCurrentAttachIndex[playerid]],
		gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_X],
		gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Y],
		gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Z],
		gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_X],
		gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Y],
		gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Z],
		gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_X],
		gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Y],
		gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Z]);

	ShowPlayerDialog(
		playerid,
		2001,
		DIALOG_STYLE_LIST,
		"Attachment Editor / Main Menu",
		string,
		"Accept",
		"Cancel");

	gEditingAttachments[playerid] = true;
}

ShowIndexList(playerid) {
	new string[512];
	
	for(new i; i < MAX_PLAYER_ATTACHED_OBJECTS; i++) {
		if(IsPlayerAttachedObjectSlotUsed(playerid, i)) {
			if(gIndexUsed[playerid][i]) {
				format(
					string,
					sizeof(string),
					"%sSlot %d (%s - %d)\n",
					string,
					i,
					AttachmentBones[gIndexBone[playerid][i]],
					gIndexModel[playerid][i]);
			} else {
				format(string, sizeof(string), "%sSlot %d (External)\n", string, i);
			}
		} else {
			format(string, sizeof(string), "%sSlot %d\n", string, i);
		}
	}

	ShowPlayerDialog(
		playerid,
		2002,
		DIALOG_STYLE_LIST,
		"Attachment Editor / Index",
		string,
		"Accept",
		"Cancel");
}

ShowModelInput(playerid) {
	ShowPlayerDialog(
		playerid,
		2003,
		DIALOG_STYLE_INPUT,
		"Attachment Editor / Model",
		"Enter a model to attach",
		"Accept", "Cancel");
}

ShowBoneList(playerid) {
	new string[512];
	
	for(new i; i < sizeof(AttachmentBones); i++) {
		format(string, sizeof(string), "%s%s\n", string, AttachmentBones[i]);
	}

	ShowPlayerDialog(
		playerid,
		2004,
		DIALOG_STYLE_LIST,
		"Attachment Editor / Bone",
		string,
		"Accept",
		"Cancel");
}

EditCoord(playerid, coord) {
	gCurrentAxisEdit[playerid] = coord;
	ShowPlayerDialog(
		playerid,
		2005,
		DIALOG_STYLE_INPUT,
		"Attachment Editor / Offset",
		"Enter a floating point value for the offset:",
		"Accept",
		"Cancel");
}

EditAttachment(playerid) {
	SetPlayerAttachedObject(playerid,
		gCurrentAttachIndex[playerid],
		gIndexModel[playerid][gCurrentAttachIndex[playerid]],
		gIndexBone[playerid][gCurrentAttachIndex[playerid]],
		gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_X],
		gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Y],
		gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Z],
		gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_X],
		gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Y],
		gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Z],
		gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_X],
		gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Y],
		gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Z]);

	EditAttachedObject(playerid, gCurrentAttachIndex[playerid]);

	gIndexUsed[playerid][gCurrentAttachIndex[playerid]] = true;
}

ClearCurrentIndex(playerid) {
	gIndexModel[playerid][gCurrentAttachIndex[playerid]] = 0;
	gIndexBone[playerid][gCurrentAttachIndex[playerid]] = 1;
	gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_X] = 0.0;
	gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Y] = 0.0;
	gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Z] = 0.0;
	gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_X] = 0.0;
	gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Y] = 0.0;
	gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Z] = 0.0;
	gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_X] = 0.0;
	gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Y] = 0.0;
	gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Z] = 0.0;
	gIndexUsed[playerid][gCurrentAttachIndex[playerid]] = false;

	RemovePlayerAttachedObject(playerid, gCurrentAttachIndex[playerid]);
	ShowMainEditMenu(playerid);
}

SaveAttachedObjects(playerid) {
	new
		str[256],
		File:file;

	if(!fexist(OUTPUT_FILE)) {
		file = fopen(OUTPUT_FILE, io_write);
	} else {
		file = fopen(OUTPUT_FILE, io_append);
	}

	if(!file) {
		err("failed to open file for writing",
			_s("filename", OUTPUT_FILE));
		return 0;
	}

	format(str, 256, "SetPlayerAttachedObject(playerid, %d, %d, %d,  %f, %f, %f,  %f, %f, %f,  %f, %f, %f); // %d\r\n",
		gCurrentAttachIndex[playerid],
		gIndexModel[playerid][gCurrentAttachIndex[playerid]],
		gIndexBone[playerid][gCurrentAttachIndex[playerid]],
		gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_X],
		gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Y],
		gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Z],
		gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_X],
		gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Y],
		gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Z],
		gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_X],
		gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Y],
		gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Z],
		GetPlayerSkin(playerid));

	fwrite(file, str);
	fclose(file);

	ShowMainEditMenu(playerid);

	return 1;
}


public OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]) {
	if(dialogid == 2001) {
		if(response) {
			switch(listitem) {
				case 0: ShowIndexList(playerid);
				case 1: ShowModelInput(playerid);
				case 2: ShowBoneList(playerid);
				case 3: EditCoord(playerid, POS_OFFSET_X);
				case 4: EditCoord(playerid, POS_OFFSET_Y);
				case 5: EditCoord(playerid, POS_OFFSET_Z);
				case 6: EditCoord(playerid, ROT_OFFSET_X);
				case 7: EditCoord(playerid, ROT_OFFSET_Y);
				case 8: EditCoord(playerid, ROT_OFFSET_Z);
				case 9: EditCoord(playerid, SCALE_X);
				case 10: EditCoord(playerid, SCALE_Y);
				case 11: EditCoord(playerid, SCALE_Z);
				case 12: EditAttachment(playerid);
				case 13: ClearCurrentIndex(playerid);
				case 14: SaveAttachedObjects(playerid);
			}
		}
	} else if(dialogid == 2002) {
		if(response) {
			gCurrentAttachIndex[playerid] = listitem;
			ShowMainEditMenu(playerid);
		} else {
			ShowMainEditMenu(playerid);
		}
		return 1;
	} else if(dialogid == 2003) {
		if(response) {
			gIndexModel[playerid][gCurrentAttachIndex[playerid]] = strval(inputtext);
			ShowMainEditMenu(playerid);
		} else {
			ShowMainEditMenu(playerid);
		}
	} else if(dialogid == 2004) {
		if(response) {
			gIndexBone[playerid][gCurrentAttachIndex[playerid]] = listitem + 1;
			ShowMainEditMenu(playerid);
		} else {
			ShowMainEditMenu(playerid);
		}
	} else if(dialogid == 2005) {
		if(response) {
			new Float:value = floatstr(inputtext);

			switch(gCurrentAxisEdit[playerid]) {
				case POS_OFFSET_X: gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_X] = value;
				case POS_OFFSET_Y: gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Y] = value;
				case POS_OFFSET_Z: gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Z] = value;
				case ROT_OFFSET_X: gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_X] = value;
				case ROT_OFFSET_Y: gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Y] = value;
				case ROT_OFFSET_Z: gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Z] = value;
				case SCALE_X: gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_X] = value;
				case SCALE_Y: gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Y] = value;
				case SCALE_Z: gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Z] = value;
			}

			SetPlayerAttachedObject(playerid,
				gCurrentAttachIndex[playerid],
				gIndexModel[playerid][gCurrentAttachIndex[playerid]],
				gIndexBone[playerid][gCurrentAttachIndex[playerid]],
				gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_X],
				gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Y],
				gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Z],
				gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_X],
				gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Y],
				gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Z],
				gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_X],
				gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Y],
				gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Z]);
		}
		ShowMainEditMenu(playerid);
	}

	return 1;
}

public OnPlayerEditAttachedObject(
	playerid, response, index, modelid, boneid,
	Float:fOffsetX, Float:fOffsetY, Float:fOffsetZ,
	Float:fRotX, Float:fRotY, Float:fRotZ,
	Float:fScaleX, Float:fScaleY, Float:fScaleZ
) {
	gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_X] = fOffsetX;
	gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Y] = fOffsetY;
	gIndexPos[playerid][gCurrentAttachIndex[playerid]][COORD_Z] = fOffsetZ;
	gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_X] = fRotX;
	gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Y] = fRotY;
	gIndexRot[playerid][gCurrentAttachIndex[playerid]][COORD_Z] = fRotZ;
	gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_X] = fScaleX;
	gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Y] = fScaleY;
	gIndexSca[playerid][gCurrentAttachIndex[playerid]][COORD_Z] = fScaleZ;

	ShowMainEditMenu(playerid);

	SetPlayerAttachedObject(
		playerid, index, modelid, boneid,
		fOffsetX, fOffsetY, fOffsetZ,
		fRotX, fRotY, fRotZ,
		fScaleX, fScaleY, fScaleZ
	);

	return 1;
}
